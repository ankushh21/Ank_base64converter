#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jul 27 22:03:28 2023

@author: Ankush Jain
"""

import base64
import sys
import os
import json

def base64_converter(inp_path, out_path):

    # inp_path = ".\Input_Word_Files\\"
    # out_path = ".\Output_Text_Files\\"
    print('Input Path : ', inp_path)
    print('Output Path : ', out_path)

    files_list = os.listdir(inp_path)
    # print('Files : ', files_list, '\n')

    for each_file in files_list:
        print(inp_path + '\\' + each_file)

        with open(inp_path + '\\' + each_file, 'rb') as f:
            data = f.read()
            b64_data = base64.b64encode(data)
            with open(out_path + '\\' + each_file[:-4]+".json","w") as j:
                json_data = json.dumps( {"filename":str(each_file),"fileContent":(b64_data).decode("utf-8")} )
                j.write((json_data))

    print('File successfully generated.')

    result = 'Check the file in : ' + out_path
    return result
        
